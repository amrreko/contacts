<?php $__env->startSection('content'); ?>
    <div class="card-body">
        <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

    </div>
    <table class="table">
        <thead class="thead-dark">
        <tr>
            <th scope="col">#</th>
            <th scope="col">Fullname</th>
            <th scope="col">SID</th>
            <th scope="col">Image</th>
            <th scope="col">Phone</th>
            <th scope="col">Facebook</th>
            <th scope="col">Created at</th>
            <th scope="col">Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($contact->id); ?></th>
                <td><a href="<?php echo e(URL::to('/contacts/'.$contact->id)); ?>"><?php echo e($contact->fullname); ?></a></td>
                <th scope="row"><?php echo e($contact->set_id); ?></th>
                <td>
                    <?php if($contact->image): ?>
                  <a href="<?php echo e($contact->image); ?>">
                      <img src="<?php echo e($contact->image); ?>" style="height: 50px;width: 50px;">
                  </a>
                    <?php else: ?>
                    <?php echo e('no image'); ?>

                    <?php endif; ?>
                </td>
                <td><?php echo e($contact->phone); ?></td>
                <td><?php echo e($contact->facebook); ?></td>
                <td><?php echo e($contact->created_at->toFormattedDateString()); ?></td>
                <td>
                    <div class="btn-group" role="group" aria-label="Basic example">
                        <a href="<?php echo e(URL::to('contacts/' . $contact->id . '/edit')); ?>">
                            <button type="button" class="btn btn-warning">Edit</button>
                        </a>&nbsp;
                        <form action="<?php echo e(url('contacts', [$contact->id])); ?>" method="POST">
                            <input type="hidden" name="_method" value="DELETE">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="submit" class="btn btn-danger" value="Delete"/>
                        </form>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\contacts\resources\views/contacts/index.blade.php ENDPATH**/ ?>