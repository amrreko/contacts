<?php $__env->startSection('content'); ?>
    <h1> <?php echo e($contact->fullname); ?></h1>

        <table class="table table-bordered" style="width: 50%;">
            <tr><td>set_id:</td><td> <?php echo e($contact->set_id); ?></td></tr>
            <td>phone:</td><td> <?php echo e($contact->phone); ?></td></tr>
            <td>facebook:</td><td> <?php echo e($contact->facebook); ?></td></tr>
            <td>image:</td><td> <?php echo e($contact->image); ?></td></tr>
            <td>from:</td><td> <?php echo e($contact->from); ?></td></tr>
            <td>city:</td><td> <?php echo e($contact->city); ?></td></tr>
            <td>address:</td><td> <?php echo e($contact->address); ?></td></tr>
            <td>danger:</td><td> <?php echo e($contact->danger); ?></td></tr>
            <td>information:</td><td> <?php echo e($contact->information); ?></td></tr>
            <td>facebook2:</td><td> <?php echo e($contact->facebook2); ?></td></tr>
            <td>image2:</td><td> <?php echo e($contact->image2); ?></td></tr>
            <td>phone2:</td><td> <?php echo e($contact->phone2); ?></td></tr>

            <td>user_id:</td></tr><td> <?php echo e($contact->user_id); ?></td></tr>
        </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\contacts\resources\views/contacts/show.blade.php ENDPATH**/ ?>